var group___e_f_m32_g230_f128___peripheral___type_defs =
[
    [ "EFM32G230F128 DMA", "d3/d03/group___e_f_m32_g230_f128___d_m_a.html", "d3/d03/group___e_f_m32_g230_f128___d_m_a" ],
    [ "EFM32G230F128 CMU", "d4/dc4/group___e_f_m32_g230_f128___c_m_u.html", "d4/dc4/group___e_f_m32_g230_f128___c_m_u" ],
    [ "EFM32G230F128 PRS", "d3/d9d/group___e_f_m32_g230_f128___p_r_s.html", "d3/d9d/group___e_f_m32_g230_f128___p_r_s" ]
];