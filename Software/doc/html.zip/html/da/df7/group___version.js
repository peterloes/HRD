var group___version =
[
    [ "_EMLIB_VERSION", "da/df7/group___version.html#ga6d1283cc853becee2508bc2dfc772096", null ],
    [ "_EMLIB_VERSION_MAJOR", "da/df7/group___version.html#ga69ba661826816055c9fc52afee0ca6ce", null ],
    [ "_EMLIB_VERSION_MINOR", "da/df7/group___version.html#gab345b096dcb0eece0d802b8df10b2c76", null ],
    [ "_EMLIB_VERSION_PATCH", "da/df7/group___version.html#ga2516db79921dc0f450574c569964132e", null ]
];