var em__emu_8h =
[
    [ "EMU_EnterEM1", "d8/d06/group___e_m_u.html#gaed0c4092bd3adc7a6679e1e2903d1267", null ],
    [ "EMU_EnterEM2", "d8/d06/group___e_m_u.html#gacadc56c5e2a8fb2890edd139b694b25b", null ],
    [ "EMU_EnterEM3", "d8/d06/group___e_m_u.html#ga9e98f9066d91dbd64c3e73254336218f", null ],
    [ "EMU_EnterEM4", "d8/d06/group___e_m_u.html#gac92115921464d7435fc714d8b9bd494b", null ],
    [ "EMU_MemPwrDown", "d8/d06/group___e_m_u.html#ga49eb5750384ff279aae225ab5922e9f1", null ],
    [ "EMU_UpdateOscConfig", "d8/d06/group___e_m_u.html#ga3d442fa018de5138afb19a2b85797099", null ],
    [ "EMU_Lock", "d8/d06/group___e_m_u.html#gaa102a7feedcfdf0165e8137495e15c81", null ],
    [ "EMU_Unlock", "d8/d06/group___e_m_u.html#gaae70d64f013a75e2d728b3a6d71e3f62", null ],
    [ "EMU_EM2Block", "d8/d06/group___e_m_u.html#ga72910c09de24f4e2f8f170dc06bd8c07", null ],
    [ "EMU_EM2UnBlock", "d8/d06/group___e_m_u.html#ga9e959a9fd56ac4a2e18877b9b839d795", null ]
];