var group___l_e_t_i_m_e_r =
[
    [ "LETIMER_Init_TypeDef", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html", [
      [ "enable", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
      [ "debugRun", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a95936f85c6ab1a7f43f02f15f172f1db", null ],
      [ "rtcComp0Enable", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a6d1aae4b4672b0af1e71e08977139d1e", null ],
      [ "rtcComp1Enable", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a11fa68376cfac9cdacca0defc2e2c52b", null ],
      [ "comp0Top", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a7ca3b6a7bbfd2be5fc4be17adf96f560", null ],
      [ "bufTop", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a1947b5b800c1447625e019013e6ab3d4", null ],
      [ "out0Pol", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a064a6e96e47a0c84ac284fcfc4cf1977", null ],
      [ "out1Pol", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a2c577b8a06beb0b1565d0d393e1c4c97", null ],
      [ "ufoa0", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a6e2e858caccad5bfabd4b9add508cafe", null ],
      [ "ufoa1", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#ac088fd4df2b7a58ed4ae9e3932536096", null ],
      [ "repMode", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a957fa5ce399b0cebb6af421f80c2b5e4", null ]
    ] ],
    [ "LETIMER_INIT_DEFAULT", "d1/dae/group___l_e_t_i_m_e_r.html#gaa409061c5239d936cd67b4d578c054b3", null ],
    [ "LETIMER_RepeatMode_TypeDef", "d1/dae/group___l_e_t_i_m_e_r.html#ga621d39064a03e229a02e2c33fd815eb2", [
      [ "letimerRepeatFree", "d1/dae/group___l_e_t_i_m_e_r.html#gga621d39064a03e229a02e2c33fd815eb2aecd049f93ca363cf8c8c4569ad811a9b", null ],
      [ "letimerRepeatOneshot", "d1/dae/group___l_e_t_i_m_e_r.html#gga621d39064a03e229a02e2c33fd815eb2a63dd96017a9e751c8cf5bfbd6ad9cf25", null ],
      [ "letimerRepeatBuffered", "d1/dae/group___l_e_t_i_m_e_r.html#gga621d39064a03e229a02e2c33fd815eb2a7bc26aed4618fc9209e44d40435aa05d", null ],
      [ "letimerRepeatDouble", "d1/dae/group___l_e_t_i_m_e_r.html#gga621d39064a03e229a02e2c33fd815eb2a80f3d6cab367aa9ab2e153176bbecf00", null ]
    ] ],
    [ "LETIMER_UFOA_TypeDef", "d1/dae/group___l_e_t_i_m_e_r.html#ga7e794807b846cd4764aa5ff96e259ba7", [
      [ "letimerUFOANone", "d1/dae/group___l_e_t_i_m_e_r.html#gga7e794807b846cd4764aa5ff96e259ba7a265c11a5fd587fa4abb5a92253152a32", null ],
      [ "letimerUFOAToggle", "d1/dae/group___l_e_t_i_m_e_r.html#gga7e794807b846cd4764aa5ff96e259ba7ab5fab86cea7ea60d6a614c1cd85febce", null ],
      [ "letimerUFOAPulse", "d1/dae/group___l_e_t_i_m_e_r.html#gga7e794807b846cd4764aa5ff96e259ba7a7a3c257077a97dfc45a3020892f0120f", null ],
      [ "letimerUFOAPwm", "d1/dae/group___l_e_t_i_m_e_r.html#gga7e794807b846cd4764aa5ff96e259ba7aa0547d98df77e356629131291036f787", null ]
    ] ],
    [ "LETIMER_CompareGet", "d1/dae/group___l_e_t_i_m_e_r.html#ga8def6260e3c54ec6dac11581dcd7c1c5", null ],
    [ "LETIMER_CompareSet", "d1/dae/group___l_e_t_i_m_e_r.html#ga5881f97abb64700592a23e213edeba21", null ],
    [ "LETIMER_CounterGet", "d1/dae/group___l_e_t_i_m_e_r.html#ga50ca4ff31c5eee289cb249fd160683f2", null ],
    [ "LETIMER_Enable", "d1/dae/group___l_e_t_i_m_e_r.html#gaca64117c08fbb558eb2feb300cef0621", null ],
    [ "LETIMER_FreezeEnable", "d1/dae/group___l_e_t_i_m_e_r.html#gaf4a565497669b1852de043374173c288", null ],
    [ "LETIMER_Init", "d1/dae/group___l_e_t_i_m_e_r.html#gaa4e7e28b4b04595a991a93b9e76c9919", null ],
    [ "LETIMER_IntClear", "d1/dae/group___l_e_t_i_m_e_r.html#ga73948168b9c0345e75551ed3f8115474", null ],
    [ "LETIMER_IntDisable", "d1/dae/group___l_e_t_i_m_e_r.html#gac559ba136bfd11379a1dc12cc45cc82e", null ],
    [ "LETIMER_IntEnable", "d1/dae/group___l_e_t_i_m_e_r.html#ga11110bb53b566e017a9248a4a8946963", null ],
    [ "LETIMER_IntGet", "d1/dae/group___l_e_t_i_m_e_r.html#gafc3fe4be7e3a67c4403c0c0a9966a893", null ],
    [ "LETIMER_IntSet", "d1/dae/group___l_e_t_i_m_e_r.html#ga8ad490c965b096e4bde9ebdc2a16ec05", null ],
    [ "LETIMER_RepeatGet", "d1/dae/group___l_e_t_i_m_e_r.html#ga8012c191a62ae300457d246f6fd13c04", null ],
    [ "LETIMER_RepeatSet", "d1/dae/group___l_e_t_i_m_e_r.html#ga99d89e7b494ea6d0a30be57444a7ba2a", null ],
    [ "LETIMER_Reset", "d1/dae/group___l_e_t_i_m_e_r.html#gaf7209283bdf0e32dd3983d2fbb078d20", null ]
];