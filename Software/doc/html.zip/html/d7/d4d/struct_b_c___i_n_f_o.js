var struct_b_c___i_n_f_o =
[
    [ "addr", "d7/d4d/struct_b_c___i_n_f_o.html#af5105c72a61e60d3b44670de20e0c3fb", null ],
    [ "type", "d7/d4d/struct_b_c___i_n_f_o.html#a4656d622112092bf57502da6d0169743", null ],
    [ "name", "d7/d4d/struct_b_c___i_n_f_o.html#a8f8f80d37794cde9472343e4487ba3eb", null ]
];