var config_8h =
[
    [ "EOL", "db/d16/config_8h.html#a4e67e9429d48a2ba8f833ee3b1dceb5d", null ],
    [ "EOS", "db/d16/config_8h.html#aadbbc7b02d94a4c18646813ac8d7dec1", null ],
    [ "NONE", "db/d16/config_8h.html#a655c84af1b0034986ff56e12e84f983d", null ],
    [ "ELEM_CNT", "db/d16/config_8h.html#a6711147f05af3a4e182e3990fe8ec33c", null ],
    [ "USE_EXT_32MHZ_CLOCK", "db/d16/config_8h.html#addbfd2969e740925e800e882c5466df7", null ],
    [ "RTC_COUNTS_PER_SEC", "db/d16/config_8h.html#ada3f8846e8c541f89986d014bbdd3a5b", null ],
    [ "AUTOREPEAT_THRESHOLD", "db/d16/config_8h.html#a1c78d3ed0e185b80cdff3f8da6ac97c6", null ],
    [ "AUTOREPEAT_RATE", "db/d16/config_8h.html#af08243d7884d8464322187154d365268", null ],
    [ "DMA_CHAN_LEUART_RX", "db/d16/config_8h.html#a53a6e284576215652a2fa2b704103959", null ],
    [ "DMA_CHAN_LEUART_TX", "db/d16/config_8h.html#a58b978b3f8629be076efcc0bee19007a", null ],
    [ "DBG_PUTC", "db/d16/config_8h.html#a81f8e47007cdb654f3c41f2829d68288", null ],
    [ "DBG_PUTS", "db/d16/config_8h.html#aa36da53aa9b0e884b03bca7e3bda37f5", null ],
    [ "IO_BIT_ADDR", "db/d16/config_8h.html#adabcfca2cb7bd9dd0b891465b9afb3c5", null ],
    [ "IO_Bit", "db/d16/config_8h.html#aa04799bbe99b88d70a1d1d846c8329ae", null ],
    [ "SRAM_BIT_ADDR", "db/d16/config_8h.html#a56be8be00098c8ab78df37519208f3f3", null ],
    [ "Bit", "db/d16/config_8h.html#a12988aba566f5d6b05bdea535508bc6b", null ],
    [ "ALARM_ID", "db/d16/config_8h.html#a99532b5a3491b4c385052e756279120b", [
      [ "ALARM_XXX", "db/d16/config_8h.html#a99532b5a3491b4c385052e756279120baf508f56c6925298d23bea178bd9ce1a0", null ],
      [ "END_ALARM_ID", "db/d16/config_8h.html#a99532b5a3491b4c385052e756279120baabfc6d192a5eb04609504912437d9515", null ]
    ] ],
    [ "EM1_MODULES", "db/d16/config_8h.html#aff38d1b694ae9fd5e5b9ee476b0fa102", [
      [ "EM1_MOD_XXX", "db/d16/config_8h.html#aff38d1b694ae9fd5e5b9ee476b0fa102a4d66e843354fc3925f5ed4115b2cdd1c", null ],
      [ "END_EM1_MODULES", "db/d16/config_8h.html#aff38d1b694ae9fd5e5b9ee476b0fa102a4cd7743861f0b7260664e1b7ac1c8072", null ]
    ] ],
    [ "drvLEUART_puts", "db/d16/config_8h.html#a67a999d88129dfef3f0f372368324885", null ],
    [ "ConsolePrintf", "db/d16/config_8h.html#a6bbc52e23201d0287b39626a6b74e3de", null ],
    [ "g_flgIRQ", "db/d16/config_8h.html#abee89156336d3515c23e1c666fc0496d", null ],
    [ "g_EM1_ModuleMask", "db/d16/config_8h.html#a5575f04e1833f1a6f7f0283903b19b9b", null ]
];