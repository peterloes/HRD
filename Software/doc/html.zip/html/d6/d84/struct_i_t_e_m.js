var struct_i_t_e_m =
[
    [ "pDesc", "d6/d84/struct_i_t_e_m.html#aa91ba72e42321ca5e6911702b316125f", null ],
    [ "Cmd", "d6/d84/struct_i_t_e_m.html#a7ae4f00bed797ed01565a54f92e1e060", null ],
    [ "Frmt", "d6/d84/struct_i_t_e_m.html#a1015edabad20a076b63d881f893f1a90", null ]
];