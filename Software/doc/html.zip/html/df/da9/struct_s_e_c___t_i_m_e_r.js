var struct_s_e_c___t_i_m_e_r =
[
    [ "Counter", "df/da9/struct_s_e_c___t_i_m_e_r.html#abef4248412159e665620f746a9d7d3f8", null ],
    [ "Function", "df/da9/struct_s_e_c___t_i_m_e_r.html#aea294ded3f9d640149bffee96e296179", null ]
];