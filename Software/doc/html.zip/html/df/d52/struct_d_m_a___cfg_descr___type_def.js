var struct_d_m_a___cfg_descr___type_def =
[
    [ "dstInc", "df/d52/struct_d_m_a___cfg_descr___type_def.html#ade331593e9d06957ec020f3280ad47c7", null ],
    [ "srcInc", "df/d52/struct_d_m_a___cfg_descr___type_def.html#a650e034d84d7fffc35e29a84f433d6da", null ],
    [ "size", "df/d52/struct_d_m_a___cfg_descr___type_def.html#a9fc3b2f84ae9a085eb08733b2e43bc91", null ],
    [ "arbRate", "df/d52/struct_d_m_a___cfg_descr___type_def.html#a8818e70c4a68adfee7c8e4da11bea088", null ],
    [ "hprot", "df/d52/struct_d_m_a___cfg_descr___type_def.html#acc18bd306b7ff90d0f106dfe42398a47", null ]
];