var struct_d_m_a___init___type_def =
[
    [ "hprot", "dd/dbf/struct_d_m_a___init___type_def.html#acc18bd306b7ff90d0f106dfe42398a47", null ],
    [ "controlBlock", "dd/dbf/struct_d_m_a___init___type_def.html#a18ca9e062df9e35dd2580dc26cd17280", null ]
];