var group___p_c_n_t =
[
    [ "PCNT_Init_TypeDef", "db/da1/struct_p_c_n_t___init___type_def.html", [
      [ "mode", "db/da1/struct_p_c_n_t___init___type_def.html#a1f88b5bc23005f236cc4294a066e647e", null ],
      [ "counter", "db/da1/struct_p_c_n_t___init___type_def.html#a51322ddb267b4729d6b5f2bb05d49fff", null ],
      [ "top", "db/da1/struct_p_c_n_t___init___type_def.html#afb76bfccb6839c141bcfa1a6914529b2", null ],
      [ "negEdge", "db/da1/struct_p_c_n_t___init___type_def.html#ada5b3c75e58caff9d75bdd144dd5252b", null ],
      [ "countDown", "db/da1/struct_p_c_n_t___init___type_def.html#a962de0b4f5864d0cd1b897c635b4a2aa", null ],
      [ "filter", "db/da1/struct_p_c_n_t___init___type_def.html#a5b85fc472953eac39c2629b1f5d68617", null ]
    ] ],
    [ "PCNT0_CNT_SIZE", "dc/d51/group___p_c_n_t.html#gaf9147680cf4def78a0d85a8056ac305d", null ],
    [ "PCNT1_CNT_SIZE", "dc/d51/group___p_c_n_t.html#gac0b5dd0a1e5062fdaf21780ef8c96643", null ],
    [ "PCNT2_CNT_SIZE", "dc/d51/group___p_c_n_t.html#gae3a1a39ad553e685d081f3d7cea568e4", null ],
    [ "PCNT_INIT_DEFAULT", "dc/d51/group___p_c_n_t.html#ga6cec823dab4c0de6e47a6939ad978290", null ],
    [ "PCNT_Mode_TypeDef", "dc/d51/group___p_c_n_t.html#ga2fb0fc7f68c902b71b271ba5687643a4", [
      [ "pcntModeDisable", "dc/d51/group___p_c_n_t.html#gga2fb0fc7f68c902b71b271ba5687643a4ad7b6ebce85e46e117dfd46723abe2b3d", null ],
      [ "pcntModeOvsSingle", "dc/d51/group___p_c_n_t.html#gga2fb0fc7f68c902b71b271ba5687643a4a6631b7a7ec35e0ea2f60307f76f15a11", null ],
      [ "pcntModeExtSingle", "dc/d51/group___p_c_n_t.html#gga2fb0fc7f68c902b71b271ba5687643a4a036410c15ce30d5b1b0e419f96dc62fe", null ],
      [ "pcntModeExtQuad", "dc/d51/group___p_c_n_t.html#gga2fb0fc7f68c902b71b271ba5687643a4a369c3b5ed067a8ac8e9acde0d977662f", null ]
    ] ],
    [ "PCNT_CounterGet", "dc/d51/group___p_c_n_t.html#ga70fe3bed7f9fc6b0823d53023fdf5f37", null ],
    [ "PCNT_CounterReset", "dc/d51/group___p_c_n_t.html#gacb21126956add214b4af318f61fd17cd", null ],
    [ "PCNT_CounterTopSet", "dc/d51/group___p_c_n_t.html#ga4f29435f61c53e4a6e86947fe1980be9", null ],
    [ "PCNT_CounterSet", "dc/d51/group___p_c_n_t.html#ga420446309a8fbbb76574d96ffc6db024", null ],
    [ "PCNT_Enable", "dc/d51/group___p_c_n_t.html#gaa8820c09f38c0237a58300bdfa53cb0e", null ],
    [ "PCNT_FreezeEnable", "dc/d51/group___p_c_n_t.html#ga0a3a18c64e545011e4b4eaef0bdc2b3d", null ],
    [ "PCNT_Init", "dc/d51/group___p_c_n_t.html#ga726934d28be99230a6025503fdbaf86d", null ],
    [ "PCNT_IntClear", "dc/d51/group___p_c_n_t.html#ga656f9c01f924fb88378bf4d77bb927a1", null ],
    [ "PCNT_IntDisable", "dc/d51/group___p_c_n_t.html#gab68278a67e797c54abf963dd6546f448", null ],
    [ "PCNT_IntEnable", "dc/d51/group___p_c_n_t.html#ga48363e8f5b035115fda26ce1c7c73953", null ],
    [ "PCNT_IntGet", "dc/d51/group___p_c_n_t.html#gad2c0d9afde7927503a4abee86862c7f1", null ],
    [ "PCNT_IntGetEnabled", "dc/d51/group___p_c_n_t.html#ga94a4c16e59e21c6550082fe5cb91db5e", null ],
    [ "PCNT_IntSet", "dc/d51/group___p_c_n_t.html#gabe2234a84d44892bb33c590f5c3857e2", null ],
    [ "PCNT_Reset", "dc/d51/group___p_c_n_t.html#gadf14f80981badc92e7a30a43caae130b", null ],
    [ "PCNT_TopBufferGet", "dc/d51/group___p_c_n_t.html#ga891fb6ed2bb9bf604783b363c87464de", null ],
    [ "PCNT_TopBufferSet", "dc/d51/group___p_c_n_t.html#gaa0a00b056f5f6404abd02de84c30d002", null ],
    [ "PCNT_TopGet", "dc/d51/group___p_c_n_t.html#ga963e01aecd570531bae9630800165ff4", null ],
    [ "PCNT_TopSet", "dc/d51/group___p_c_n_t.html#gac40297f0dcf3f1502b8cbca2aced1466", null ]
];