var struct_w_d_o_g___init___type_def =
[
    [ "enable", "de/d51/struct_w_d_o_g___init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "debugRun", "de/d51/struct_w_d_o_g___init___type_def.html#a95936f85c6ab1a7f43f02f15f172f1db", null ],
    [ "em2Run", "de/d51/struct_w_d_o_g___init___type_def.html#a9a783f004392dd6c54bc558f346e787f", null ],
    [ "em3Run", "de/d51/struct_w_d_o_g___init___type_def.html#aa0d4eab9be3a4d29c14caf17a17c549a", null ],
    [ "em4Block", "de/d51/struct_w_d_o_g___init___type_def.html#a9206da7aed46f68595b59f593b8087c4", null ],
    [ "swoscBlock", "de/d51/struct_w_d_o_g___init___type_def.html#a49dc8541c8a6205fe10311e1ace5eb62", null ],
    [ "lock", "de/d51/struct_w_d_o_g___init___type_def.html#a26e9c310f0ff6151d48550c2b6b2b185", null ],
    [ "clkSel", "de/d51/struct_w_d_o_g___init___type_def.html#a0a43a98f960c43c3e1da0813930b7b43", null ],
    [ "perSel", "de/d51/struct_w_d_o_g___init___type_def.html#ab4215fff95e8aaf949aa3cc40a56ca3a", null ]
];