var group___e_f_m32_g___d_m_a___d_e_s_c_r_i_p_t_o_r =
[
    [ "DMA_DESCRIPTOR_TypeDef", "d9/d08/struct_d_m_a___d_e_s_c_r_i_p_t_o_r___type_def.html", [
      [ "SRCEND", "d9/d08/struct_d_m_a___d_e_s_c_r_i_p_t_o_r___type_def.html#a79b0a53da4665c07610dbeab0907388e", null ],
      [ "DSTEND", "d9/d08/struct_d_m_a___d_e_s_c_r_i_p_t_o_r___type_def.html#adff4db4f7a96b15edbfa6b2090f9853b", null ],
      [ "CTRL", "d9/d08/struct_d_m_a___d_e_s_c_r_i_p_t_o_r___type_def.html#a15fc8d35f045f329b80c544bef35ff64", null ],
      [ "USER", "d9/d08/struct_d_m_a___d_e_s_c_r_i_p_t_o_r___type_def.html#a6b3817d7716314788d54cdca4e6d5d98", null ]
    ] ]
];