var version_8c =
[
    [ "prjVersion", "d2/d0b/version_8c.html#aa79abddb3b6f714849141366d183765c", null ],
    [ "prjDate", "d2/d0b/version_8c.html#a3d67fc5542408aa36675cbc83b19d52a", null ],
    [ "prjTime", "d2/d0b/version_8c.html#a05704080f8e2a859cdeb4480b0db9c81", null ]
];